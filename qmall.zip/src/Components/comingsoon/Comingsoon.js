import React from 'react'


class Comingsoon extends React.Component{



   render(){
        return(
          <section className="login-block" >

        <div className="container">
          <div className="row">
            <div className="col-sm-12">

              
                <div className="text-center">
                  <img src="./assets/images/Qmall_logo.png" style={{width:"290px"}} alt="QMall" />

                  <h1></h1>
                </div>
                
               
              
            </div>
            
          </div>
          <div className="row">
            <div className="col-sm-12">
               <h1 style={{color:"#fff",textAlign:"center",fontSize:"50px",fontFamily:"Arial" }}>COMING SOON!!</h1>
               </div>
            
          </div>
        </div>
      </section>
        )
    }

}

export default Comingsoon