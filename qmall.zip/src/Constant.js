module.exports = {
    getAPI: function () {
        // return "http://109.228.53.69";
        // return "http://www.qmallapp.com/api";
        return "https://qmallapp.com/api";
        // return "http://204.48.26.50:9000";
    },
    getDefaultCurrrency: function () {
        return "KWD";
    }
}